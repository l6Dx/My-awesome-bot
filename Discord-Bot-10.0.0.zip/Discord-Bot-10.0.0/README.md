# Discord-Bot
Discord bot with over 400 commands.
This contains: Moderation, Music, Economy and much more!

Discord: https://discord.gg/qHXxpQKC2H

| Category | 
| ------------- | 
| AFK | 
| Announcement | 
| AutoMod |
| AutoSetup |
| Birthdays |
| Bot | 
| Casino |
| Config | 
| Custom-Commands | 
| Developers |
| Economy |
| Family | 
| Fun |
| Games |
| Giveaway |
| Guild |
| Images |
| Invites |
| Levels |
| Messages |
| Moderation |
| Music |
| NotePad |
| Profile |
| Radio |
| ReactionRoles |
| Search |
| Serverstats | 
| Setup |
| SoundBoard |
| StickyMessages |
| Suggestions |
| Thanks |
| Tickets |
| Tools |
| Voice |

*You may not claim this as your own!!*
**Copyright to DotwoodMedia and CorwinDev**
